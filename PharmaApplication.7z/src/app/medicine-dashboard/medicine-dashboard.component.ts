import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import {FormBuilder,FormGroup,FormControl} from '@angular/forms';
import { Medicinemodel } from './medicine.model';
import{ApiService} from '../shared/api.service';

@Component({
  selector: 'app-medicine-dashboard',
  templateUrl: './medicine-dashboard.component.html',
  styleUrls: ['./medicine-dashboard.component.css']
})
export class MedicineDashboardComponent implements OnInit {
  dataSource: any;
  Name!: string;

  
  ngOnInit(): void {
    this.formValue=this.formbuilder.group({
      Name:[''],
      Manufacturer:[''],
      BatchNo:[''],
      ExpirationDate:[''],
      Price:[''],
      Type:['']
    })
    this.getAllMedicine();
    this.typeselected="select-type";

  }
  showmanufacturer:boolean=true;
  showprice:boolean=true;
  showtype:boolean=true;
  showbatchno:boolean=true;
  showexpiration:boolean=true;
  typeselected!:String
  formValue: any=FormGroup;
  closeResult: string="";
  medicineobj: Medicinemodel=new Medicinemodel(); 
  medicinedata:any;
  showadd!:boolean;
  showupdate!:boolean;
  

  HideMe(s: number){
    if (s==1)
      this.showmanufacturer=!this.showmanufacturer;
    else if(s==2)
      this.showbatchno=!this.showbatchno;
    else if(s==3)
      this.showexpiration=!this.showexpiration;
    else if(s==4)
    this.showprice=!this.showprice;
    else if(s==5)
    this.showtype=!this.showtype;
  }

  ClickAdd(){
    this.formValue.reset();
    this.showadd=true;
    this.showupdate=false;
  }
  
  postMedicineDetails(){
    this.medicineobj.Name=this.formValue.value.Name;
    this.medicineobj.Manufacturer=this.formValue.value.Manufacturer;
    this.medicineobj.BatchNo=this.formValue.value.BatchNo;
    this.medicineobj.ExpirationDate=this.formValue.value.ExpirationDate;
    this.medicineobj.Price=this.formValue.value.Price;
    this.medicineobj.Type=this.formValue.value.Type;

    this.api.postMedicine(this.medicineobj).subscribe(res=>{
      console.log(res);
      alert("Medicine added");
      let reference=document.getElementById('cancel')
      reference?.click();
      this.formValue.reset();
      this.getAllMedicine();
    },
    err=>{
      console.log(err);
      alert("something went wrong");
  })
  }
  getAllMedicine(){
    this.api.getMedicine().subscribe(res=>{
      this.medicinedata=res
    },
    err=>{
      console.log(err);
      alert("error");
    })
  }
  deleteMedicine(row:any){
    this.api.deleteMedicine(row.id).subscribe(res=>{
      alert("Medicine Deleted");
      this.getAllMedicine();

    })
  }
  onEdit(row:any){
    this.showadd=false;
    this.showupdate=true;
    this.medicineobj.id=row.id;
    this.formValue.controls['Name'].setValue(row.Name);
    this.formValue.controls['Manufacturer'].setValue(row.Manufacturer);
    this.formValue.controls['BatchNo'].setValue(row.BatchNo);
    this.formValue.controls['ExpirationDate'].setValue(row.ExpirationDate);
    this.formValue.controls['Price'].setValue(row.Price);
    this.formValue.controls['Type'].setValue(row.Type);
  }
  UpdateDetails(){
    this.medicineobj.Name=this.formValue.value.Name;
    this.medicineobj.Manufacturer=this.formValue.value.Manufacturer;
    this.medicineobj.BatchNo=this.formValue.value.BatchNo;
    this.medicineobj.ExpirationDate=this.formValue.value.ExpirationDate;
    this.medicineobj.Price=this.formValue.value.Price;
    this.medicineobj.Type=this.formValue.value.Type;
    this.api.updateMedicine(this.medicineobj,this.medicineobj.id).subscribe(res=>{
      alert("Updated sucessfully");
      let reference=document.getElementById('cancel')
      reference?.click();
      this.formValue.reset();
      this.getAllMedicine();
    })

  }
  constructor(private modalService: NgbModal,private formbuilder:FormBuilder,private api:ApiService) {}
    
  open(content: any) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }

  }
  Search(){
    if(this.Name=="")
    {
      this.ngOnInit();
    }
    else{
      
    }
  }

}
