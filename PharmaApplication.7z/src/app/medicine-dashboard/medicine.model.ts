
export class Medicinemodel{
    id:number=0;
    Name: string='';
    Manufacturer: string='';
    BatchNo: number=0;
    ExpirationDate: string='';
    Price: number=0;
    Type: string='';
}